package com.example.typingguard.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val PrimaryBlue = Color(0xFF4F46E5)
val PrimaryBlueDark = Color(0xFF6366F1)
val SecondaryTeal = Color(0xFF0D9488)
val SurfaceDark = Color(0xFF0F172A)
val CardDark = Color(0xFF1E293B)
val ErrorRed = Color(0xFFEF4444)
