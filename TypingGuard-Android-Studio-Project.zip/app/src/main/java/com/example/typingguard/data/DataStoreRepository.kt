package com.example.typingguard.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

// تعریف DataStore به صورت اکستنشن پراپرتی برای کانتکست
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "typing_guard_preferences")

/**
 * مدیریت ذخیره‌سازی محلی و خواندن/نوشتن کلمات ممنوعه در DataStore (Preferences).
 * تمامی اطلاعات به صورت محلی در گوشی کاربر ذخیره می‌شوند و نیاز به اتصال اینترنت نیست.
 */
class DataStoreRepository(private val context: Context) {

    companion object {
        private val KEY_BLOCKED_WORDS = stringPreferencesKey("key_blocked_words_json")
        private val KEY_MASTER_GUARD = booleanPreferencesKey("key_master_guard_enabled")

        // نمونه‌های پیش‌فرض برای شروع اولیه اپلیکیشن
        private val DEFAULT_WORDS = listOf(
            BlockedWord(text = "قمار", isEnabled = true),
            BlockedWord(text = "bet", isEnabled = true),
            BlockedWord(text = "کازینو", isEnabled = true),
            BlockedWord(text = "password123", isEnabled = false)
        )
    }

    /**
     * جریان داده وضعیت کلید اصلی محافظت (Master Protection)
     */
    val isMasterProtectionEnabled: Flow<Boolean> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[KEY_MASTER_GUARD] ?: true
        }

    /**
     * تغییر وضعیت کلید محافظت اصلی
     */
    suspend fun setMasterProtectionEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_MASTER_GUARD] = enabled
        }
    }

    /**
     * جریان داده لیست کلمات ممنوعه
     */
    val blockedWordsFlow: Flow<List<BlockedWord>> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            val jsonString = preferences[KEY_BLOCKED_WORDS]
            if (jsonString.isNullOrEmpty()) {
                DEFAULT_WORDS
            } else {
                deserializeWords(jsonString)
            }
        }

    /**
     * افزودن کلمه جدید
     * @return true در صورت موفقیت، false در صورت تکراری یا خالی بودن
     */
    suspend fun addWord(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return false

        val currentList = blockedWordsFlow.first().toMutableList()
        // جلوگیری از ثبت کلمه تکراری (case-insensitive)
        if (currentList.any { it.text.equals(trimmed, ignoreCase = true) }) {
            return false
        }

        currentList.add(0, BlockedWord(text = trimmed, isEnabled = true))
        saveWords(currentList)
        return true
    }

    /**
     * ویرایش متن و وضعیت یک کلمه موجود
     */
    suspend fun updateWord(id: String, newText: String, isEnabled: Boolean) {
        val trimmed = newText.trim()
        if (trimmed.isEmpty()) return

        val currentList = blockedWordsFlow.first().map { item ->
            if (item.id == id) {
                item.copy(text = trimmed, isEnabled = isEnabled)
            } else {
                item
            }
        }
        saveWords(currentList)
    }

    /**
     * تغییر وضعیت فعال/غیرفعال بودن یک کلمه
     */
    suspend fun toggleWordStatus(id: String) {
        val currentList = blockedWordsFlow.first().map { item ->
            if (item.id == id) {
                item.copy(isEnabled = !item.isEnabled)
            } else {
                item
            }
        }
        saveWords(currentList)
    }

    /**
     * حذف یک کلمه از لیست
     */
    suspend fun deleteWord(id: String) {
        val currentList = blockedWordsFlow.first().filter { it.id != id }
        saveWords(currentList)
    }

    private suspend fun saveWords(list: List<BlockedWord>) {
        val jsonString = serializeWords(list)
        context.dataStore.edit { preferences ->
            preferences[KEY_BLOCKED_WORDS] = jsonString
        }
    }

    private fun serializeWords(list: List<BlockedWord>): String {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("text", item.text)
                put("isEnabled", item.isEnabled)
                put("createdAt", item.createdAt)
            }
            array.put(obj)
        }
        return array.toString()
    }

    private fun deserializeWords(jsonString: String): List<BlockedWord> {
        val list = mutableListOf<BlockedWord>()
        try {
            val array = JSONArray(jsonString)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    BlockedWord(
                        id = obj.optString("id"),
                        text = obj.optString("text"),
                        isEnabled = obj.optBoolean("isEnabled", true),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {
            return DEFAULT_WORDS
        }
        return list
    }
}
