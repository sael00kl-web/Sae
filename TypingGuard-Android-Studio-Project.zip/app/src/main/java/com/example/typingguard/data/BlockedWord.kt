package com.example.typingguard.data

import java.util.UUID

/**
 * مدل داده‌ای برای ذخیره هر کلمه یا عبارت ممنوعه.
 *
 * @param id شناسه یکتا برای هر آیتم
 * @param text عبارت یا کلمه ممنوعه (پشتیبانی کامل از فارسی و انگلیسی)
 * @param isEnabled وضعیت فعال یا غیرفعال بودن بررسی این کلمه
 * @param createdAt زمان ایجاد کلمه
 */
data class BlockedWord(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
