package com.example.typingguard.viewmodel

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Application
import android.content.Context
import android.view.accessibility.AccessibilityManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.typingguard.data.BlockedWord
import com.example.typingguard.data.DataStoreRepository
import com.example.typingguard.service.TypingGuardService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiMessage(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val isError: Boolean = false
)

/**
 * ویومدل صفحه اصلی با استفاده از StateFlow برای اتصال به UI در Jetpack Compose
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = DataStoreRepository(application)

    // جریان داده لیست کلمات ممنوعه
    val blockedWords: StateFlow<List<BlockedWord>> = repository.blockedWordsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // وضعیت کلید محافظت اصلی
    val isMasterProtectionEnabled: StateFlow<Boolean> = repository.isMasterProtectionEnabled
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = true
        )

    // وضعیت فعال بودن سرویس دسترسی در تنظیمات اندروید
    private val _isAccessibilityEnabled = MutableStateFlow(false)
    val isAccessibilityEnabled: StateFlow<Boolean> = _isAccessibilityEnabled.asStateFlow()

    // پیام‌های فیدبک کاربر (اسنک‌بار یا دیالوگ)
    private val _uiMessage = MutableStateFlow<UiMessage?>(null)
    val uiMessage: StateFlow<UiMessage?> = _uiMessage.asStateFlow()

    init {
        checkAccessibilityServiceStatus()
    }

    /**
     * بررسی فعال بودن سرویس دسترسی TypingGuardService در تنظیمات سیستم
     */
    fun checkAccessibilityServiceStatus() {
        val context = getApplication<Application>()
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)

        val isRunning = enabledServices?.any { service ->
            service.resolveInfo?.serviceInfo?.name == TypingGuardService::class.java.name
        } ?: false

        _isAccessibilityEnabled.value = isRunning
    }

    fun toggleMasterProtection() {
        viewModelScope.launch {
            val current = isMasterProtectionEnabled.value
            repository.setMasterProtectionEnabled(!current)
        }
    }

    fun addBlockedWord(text: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val trimmed = text.trim()
            if (trimmed.isEmpty()) {
                _uiMessage.value = UiMessage(text = "متن کلمه نمی‌تواند خالی باشد", isError = true)
                return@launch
            }
            val success = repository.addWord(trimmed)
            if (success) {
                _uiMessage.value = UiMessage(text = "کلمه با موفقیت اضافه شد", isError = false)
                onSuccess()
            } else {
                _uiMessage.value = UiMessage(text = "این کلمه قبلاً اضافه شده است", isError = true)
            }
        }
    }

    fun updateBlockedWord(id: String, newText: String, isEnabled: Boolean, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val trimmed = newText.trim()
            if (trimmed.isEmpty()) {
                _uiMessage.value = UiMessage(text = "متن کلمه نمی‌تواند خالی باشد", isError = true)
                return@launch
            }
            repository.updateWord(id, trimmed, isEnabled)
            _uiMessage.value = UiMessage(text = "تغییرات ذخیره شد", isError = false)
            onSuccess()
        }
    }

    fun toggleWord(id: String) {
        viewModelScope.launch {
            repository.toggleWordStatus(id)
        }
    }

    fun deleteWord(id: String) {
        viewModelScope.launch {
            repository.deleteWord(id)
            _uiMessage.value = UiMessage(text = "کلمه حذف گردید", isError = false)
        }
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }
}
