package com.example.typingguard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typingguard.data.BlockedWord
import com.example.typingguard.ui.theme.TypingGuardTheme
import com.example.typingguard.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TypingGuardTheme {
                TypingGuardApp(
                    viewModel = viewModel,
                    onOpenAccessibilitySettings = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        startActivity(intent)
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // به‌روزرسانی وضعیت سرویس دسترسی پس از بازگشت از صفحه تنظیمات
        viewModel.checkAccessibilityServiceStatus()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypingGuardApp(
    viewModel: MainViewModel,
    onOpenAccessibilitySettings: () -> Unit
) {
    val blockedWords by viewModel.blockedWords.collectAsState()
    val isMasterActive by viewModel.isMasterProtectionEnabled.collectAsState()
    val isAccessibilityActive by viewModel.isAccessibilityEnabled.collectAsState()
    val uiMessage by viewModel.uiMessage.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var wordToEdit by remember { mutableStateOf<BlockedWord?>(null) }
    var showHelpDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiMessage) {
        uiMessage?.let {
            snackbarHostState.showSnackbar(it.text)
            viewModel.clearUiMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "TypingGuard",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    // سوییچ محافظت اصلی
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = if (isMasterActive) "محافظت روشن" else "خاموش",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isMasterActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(
                            checked = isMasterActive,
                            onCheckedChange = { viewModel.toggleMasterProtection() }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = stringResource(R.string.add_word))
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // کارت وضعیت سرویس دسترسی اندروید
            item {
                Spacer(modifier = Modifier.height(4.dp))
                AccessibilityStatusCard(
                    isServiceEnabled = isAccessibilityActive,
                    onOpenSettings = onOpenAccessibilitySettings,
                    onShowHelp = { showHelpDialog = true }
                )
            }

            // هدر بخش کلمات ممنوعه با تعداد
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.blocked_words_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${blockedWords.count { it.isEnabled }} فعال از ${blockedWords.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // لیست کلمات یا وضعیت خالی
            if (blockedWords.isEmpty()) {
                item {
                    EmptyWordsState(onAddClick = { showAddDialog = true })
                }
            } else {
                items(
                    items = blockedWords,
                    key = { it.id }
                ) { word ->
                    BlockedWordItem(
                        word = word,
                        onToggle = { viewModel.toggleWord(word.id) },
                        onEdit = { wordToEdit = word },
                        onDelete = { viewModel.deleteWord(word.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(72.dp)) // فضای انتهای لیست برای FAB
            }
        }
    }

    // دیالوگ افزودن کلمه جدید
    if (showAddDialog) {
        WordInputDialog(
            title = stringResource(R.string.add_word),
            initialText = "",
            onConfirm = { text ->
                viewModel.addBlockedWord(text) {
                    showAddDialog = false
                }
            },
            onDismiss = { showAddDialog = false }
        )
    }

    // دیالوگ ویرایش کلمه
    wordToEdit?.let { word ->
        WordInputDialog(
            title = stringResource(R.string.edit_word),
            initialText = word.text,
            onConfirm = { newText ->
                viewModel.updateBlockedWord(word.id, newText, word.isEnabled) {
                    wordToEdit = null
                }
            },
            onDismiss = { wordToEdit = null }
        )
    }

    // دیالوگ راهنمای فعال‌سازی سرویس دسترسی
    if (showHelpDialog) {
        AccessibilityHelpDialog(
            onDismiss = { showHelpDialog = false },
            onGoToSettings = {
                showHelpDialog = false
                onOpenAccessibilitySettings()
            }
        )
    }
}

/**
 * کارت وضعیت سرویس دسترسی با دکمه هدایت به تنظیمات
 */
@Composable
fun AccessibilityStatusCard(
    isServiceEnabled: Boolean,
    onOpenSettings: () -> Unit,
    onShowHelp: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isServiceEnabled)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            else
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isServiceEnabled) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isServiceEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isServiceEnabled) "سرویس دسترسی فعال است" else "سرویس دسترسی غیرفعال است",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isServiceEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                }

                TextButton(onClick = onShowHelp) {
                    Text("راهنما", style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isServiceEnabled)
                    "سرویس در پس‌زمینه آماده است و کلمات ممنوعه را هنگام تایپ بلافاصله پاک می‌کند."
                else
                    "برای شروع کار، روی دکمه زیر زده و گزینه TypingGuard را در بخش Accessibility فعال نمایید.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onOpenSettings,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isServiceEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            ) {
                Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isServiceEnabled) "مشاهده در تنظیمات دسترسی" else "فعال‌سازی سرویس در تنظیمات",
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/**
 * ردیف هر کلمه ممنوعه در LazyColumn
 */
@Composable
fun BlockedWordItem(
    word: BlockedWord,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = word.text,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = if (word.isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (word.isEnabled) "فعال" else "غیرفعال شده",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (word.isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "ویرایش",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Switch(
                    checked = word.isEnabled,
                    onCheckedChange = { onToggle() },
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}

/**
 * وضعیت خالی بدون کلمه ممنوعه
 */
@Composable
fun EmptyWordsState(onAddClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Block,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "هیچ کلمه ممنوعه‌ای ثبت نشده است",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "برای شروع کلماتی مانند قمار، فحش یا اطلاعات حساس را اضافه کنید.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onAddClick) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("افزودن اولین کلمه")
            }
        }
    }
}

/**
 * دیالوگ ثبت و ویرایش کلمه
 */
@Composable
fun WordInputDialog(
    title: String,
    initialText: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initialText) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = title, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(
                    text = "کلمه یا عبارت ممنوعه مورد نظر را وارد نمایید (فارسی یا انگلیسی):",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("مثلاً: قمار یا bet") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(text) },
                enabled = text.trim().isNotEmpty()
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

/**
 * دیالوگ راهنمای فعال‌سازی سرویس دسترسی در تنظیمات اندروید
 */
@Composable
fun AccessibilityHelpDialog(
    onDismiss: () -> Unit,
    onGoToSettings: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        title = {
            Text("نحوه فعال‌سازی در اندروید", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("مراحل فعال‌سازی سرویس محافظ تایپ:", fontWeight = FontWeight.SemiBold)
                Text("۱. روی دکمه «ورود به تنظیمات دسترسی» بزنید.")
                Text("۲. در صفحه باز شده، گزینه «برنامه‌های دانلود شده» (Downloaded Apps) یا مستقیماً «TypingGuard Service» را پیدا کنید.")
                Text("۳. روی آن بزنید و سوییچ «استفاده از TypingGuard» را فعال کنید.")
                Text("۴. پیام تأیید اندروید را تأیید فرمایید.")
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "نکته حریم خصوصی: این اپ هیچ مجوزی برای دسترسی به اینترنت ندارد و اطلاعات فیلدهای رمز عبور به هیچ وجه خوانده نمی‌شوند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            Button(onClick = onGoToSettings) {
                Text("ورود به تنظیمات دسترسی")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("متوجه شدم")
            }
        }
    )
}
