# TypingGuard (محافظ تایپ) - Android Native Project

پروژه کامل اپلیکیشن اندروید نیتیو با Kotlin و Jetpack Compose برای جلوگیری از تایپ کلمات، عبارات یا الگوهای ممنوعه در سایر برنامه‌های گوشی با استفاده از **Accessibility Service**.

## مشخصات فنی:
- **Language:** Kotlin 2.0
- **UI Toolkit:** Jetpack Compose + Material 3
- **Architecture:** MVVM (ViewModel + StateFlow)
- **Local Storage:** Jetpack DataStore (Preferences)
- **Min SDK:** 26 (Android 8.0 Oreo)
- **Target SDK:** 34 (Android 14)
- **Package Name:** `com.example.typingguard`
- **Permissions:** No INTERNET permission (100% Offline & Private)

---

## ساختار فایل‌های پروژه:
```
├── build.gradle.kts
├── settings.gradle.kts
├── gradle/libs.versions.toml
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/
        │   ├── xml/accessibility_service_config.xml
        │   ├── values/strings.xml
        │   ├── values-fa/strings.xml
        │   └── values/themes.xml
        └── java/com/example/typingguard/
            ├── MainActivity.kt
            ├── service/TypingGuardService.kt
            ├── data/
            │   ├── BlockedWord.kt
            │   └── DataStoreRepository.kt
            ├── viewmodel/MainViewModel.kt
            └── ui/theme/
                ├── Color.kt
                └── Theme.kt
```

---

## نحوه اجرای پروژه در Android Studio:
1. پوشه پروژه را در **Android Studio Hedgehog** یا جدیدتر باز کنید (`Open`).
2. اجازه دهید گریدل پکیج‌ها را سینک کند (`Sync Project with Gradle Files`).
3. پروژه را روی یک شبیه‌ساز (Emulator) یا گوشی واقعی با Android 8+ ران کنید.
4. پس از باز شدن برنامه، دکمه **«فعال‌سازی سرویس در تنظیمات»** را بزنید و در تنظیمات Accessibility گوشی، سرویس **TypingGuard Service** را فعال کنید.
5. وارد هر برنامه‌ای مثل WhatsApp، Telegram یا مرورگر شوید و یکی از کلمات ممنوعه تعریف‌شده را تایپ کنید. سرویس فوراً کلمه را پاک می‌کند!
