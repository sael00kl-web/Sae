package com.example.typingguard.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.example.typingguard.R
import com.example.typingguard.data.DataStoreRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * سرویس دسترسی (Accessibility Service) با نام TypingGuardService
 *
 * وظایف:
 * ۱. گوش دادن به رویدادهای تغییر متن (TYPE_VIEW_TEXT_CHANGED).
 * ۲. نادیده گرفتن فیلدهای رمز عبور (Password Fields) جهت حفظ امنیت و حریم خصوصی.
 * ۳. بررسی این که آیا متن واردشده شامل کلمات ممنوعه فعال است یا خیر.
 * ۴. در صورت یافتن کلمه ممنوعه، پاک کردن کل فیلد ورودی با ACTION_SET_TEXT.
 * ۵. جلوگیری از حلقه بی‌نهایت (Infinite Loop Prevention) با استفاده از پرچم داخلی isClearingText.
 */
class TypingGuardService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var repository: DataStoreRepository

    /**
     * پرچم داخلی برای جلوگیری از حلقه بینهایت:
     * وقتی خود سرویس متن را پاک می‌کند، رویداد جدید TYPE_VIEW_TEXT_CHANGED صادر می‌شود.
     * با این پرچم، رویداد ناشی از پاکسازی خود سرویس نادیده گرفته می‌شود.
     */
    @Volatile
    private var isClearingText: Boolean = false

    override fun onCreate() {
        super.onCreate()
        repository = DataStoreRepository(applicationContext)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        // پیکربندی پارامترهای سرویس دسترسی
        serviceInfo = serviceInfo?.apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            notificationTimeout = 50
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // اگر خود سرویس در حال پاکسازی متن است، رویداد را رد کن تا لوپ بی‌نهایت رخ ندهد
        if (isClearingText) return

        // بررسی رویداد تغییر متن
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            val source: AccessibilityNodeInfo = event.source ?: return

            // نکته امنیتی مهم: فیلدهای رمز عبور را به هیچ وجه بررسی یا دستکاری نکنید
            if (source.isPassword) {
                source.recycle()
                return
            }

            // اطمینان از اینکه ویو قابل ویرایش است
            if (!source.isEditable) {
                source.recycle()
                return
            }

            // خواندن متن جاری از ویو
            val currentText = source.text?.toString() ?: ""
            if (currentText.isEmpty()) {
                source.recycle()
                return
            }

            // بررسی در کوروتین برای جلوگیری از بلاک شدن نخ UI سیستم
            serviceScope.launch {
                try {
                    // بررسی فعال بودن کلید اصلی محافظت
                    val isMasterEnabled = repository.isMasterProtectionEnabled.first()
                    if (!isMasterEnabled) {
                        return@launch
                    }

                    // دریافت لیست کلمات ممنوعه فعال
                    val activeBlockedWords = repository.blockedWordsFlow.first()
                        .filter { it.isEnabled }

                    if (activeBlockedWords.isEmpty()) {
                        return@launch
                    }

                    // بررسی وجود هر یک از کلمات ممنوعه در متن جاری (عدم حساسیت به بزرگی و کوچکی حروف)
                    val matchedWord = activeBlockedWords.firstOrNull { blockedWord ->
                        currentText.contains(blockedWord.text, ignoreCase = true)
                    }

                    if (matchedWord != null) {
                        // فعال‌سازی پرچم جلوگیری از حلقه بی‌نهایت قبل از ارسال فرمان پاک‌سازی
                        isClearingText = true

                        // انجام عمل پاک‌سازی روی ترد اصلی اندروید
                        Handler(Looper.getMainLooper()).post {
                            try {
                                val arguments = Bundle().apply {
                                    putCharSequence(
                                        AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                                        ""
                                    )
                                }
                                val isCleared = source.performAction(
                                    AccessibilityNodeInfo.ACTION_SET_TEXT,
                                    arguments
                                )

                                if (isCleared) {
                                    Toast.makeText(
                                        applicationContext,
                                        applicationContext.getString(R.string.toast_word_cleared),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } finally {
                                // تاخیر کوتاه برای آرام شدن دریافت رویدادها در سیستم عامل
                                Handler(Looper.getMainLooper()).postDelayed({
                                    isClearingText = false
                                }, 300)
                            }
                        }
                    }
                } finally {
                    source.recycle()
                }
            }
        }
    }

    override fun onInterrupt() {
        // در صورت قطع موقت سرویس توسط سیستم، پرچم ریست می‌شود
        isClearingText = false
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
